//
//  Operators.swift
//  Quick Colour
//
//  Created by Henrik Thoroe on 29.01.18.
//  Copyright © 2018 Henrik Thoroe. All rights reserved.
//

import Foundation

infix operator ~~
infix operator **

func ~~(pattern: Double, value: Range<Int>) -> Bool {
    if pattern >= Double(value.lowerBound), pattern < Double(value.upperBound) {
        return true
    } else {
        return false
    }
}

func ~~(pattern: Double, value: ClosedRange<Int>) -> Bool {
    if pattern >= Double(value.lowerBound), pattern <= Double(value.upperBound) {
        return true
    } else {
        return false
    }
}

func **(number: Int, power: Int) -> Int {
    return Int(pow(Double(number), Double(power)))
}

func **(number: Double, power: Double) -> Double {
    return pow(number, power)
}

func **(number: CGFloat, power: CGFloat) -> CGFloat {
    return pow(number, power)
}

func **(number: UInt, power: UInt) -> UInt {
    return UInt(pow(Double(number), Double(power)))
}

func **(number: Int, power: Int) -> Double {
    return pow(Double(number), Double(power))
}
