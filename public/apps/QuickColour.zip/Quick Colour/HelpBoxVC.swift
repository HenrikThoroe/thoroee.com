//
//  HelpBoxVC.swift
//  Quick Colour
//
//  Created by Henrik Thoroe on 03.02.18.
//  Copyright © 2018 Henrik Thoroe. All rights reserved.
//

import Cocoa

class HelpBoxVC: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear() {
        self.view.window?.makeKeyAndOrderFront(self)
    }
    
}
