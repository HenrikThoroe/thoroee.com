//
//  Color.swift
//  Quick Colour
//
//  Created by Henrik Thoroe on 30.01.18.
//  Copyright © 2018 Henrik Thoroe. All rights reserved.
//

import Cocoa

struct Color {
    //    MARK: - Properties
    
    //    MARK: Private
    
    private var cCalculator: ColorCalculator
    
    private var internalHSL: (hue: Double, saturation: Double, lightness: Double)
    
    private var internalHSB: (hue: Double, saturation: Double, brightness: Double)
    
    private var internalRGB: (red: Double, green: Double, blue: Double)
    
    private var internalCMYK: (cyan: Double, magenta: Double, yellow: Double, black: Double)
    
    private var internalAlpha: Double
    
    //    MARK: Public
    
    public var hex: String {
        var red = String(format: "%x", Int((self.internalRGB.red * 255).rounded()))
        var green = String(format: "%x", Int((self.internalRGB.green * 255).rounded()))
        var blue = String(format: "%x", Int((self.internalRGB.blue * 255).rounded()))
        
        while red.len < 2 {
            red = "0" + red
        }
        
        while green.len < 2 {
            green = "0" + green
        }
        
        while blue.len < 2 {
            blue = "0" + blue
        }
        
        let hexStr = (red + green + blue).variousChars.len == 1 ? "#" + (red + green + blue)[0, 3] : "#" + (red + green + blue)
        
        return hexStr
    }
    
    public var alpha: Double {
        return self.internalAlpha
    }
    
    public var hsl: (hue: Double, saturation: Double, lightness: Double) {
        return self.internalHSL
    }
    
    public var hsb: (hue: Double, saturation: Double, brightness: Double) {
        return self.internalHSB
    }
    
    public var rgb: (red: Double, green: Double, blue: Double) {
        return self.internalRGB
    }
    
    public var cmyk: (cyan: Double, magenta: Double, yellow: Double, black: Double) {
        return self.internalCMYK
    }
    
    public var hsla: (hue: Double, saturation: Double, lightness: Double, alpha: Double) {
        return (
            hue: self.internalHSL.hue,
            saturation: self.internalHSL.saturation,
            lightness: self.internalHSL.lightness,
            alpha: self.internalAlpha
        )
    }
    
    public var hsba: (hue: Double, saturation: Double, brightness: Double, alpha: Double) {
        return (
            hue: self.internalHSB.hue,
            saturation: self.internalHSB.saturation,
            brightness: self.internalHSB.brightness,
            alpha: self.internalAlpha
        )
    }
    
    public var rgba: (red: Double, green: Double, blue: Double, alpha: Double) {
        return (
            red: self.internalRGB.red,
            green: self.internalRGB.green,
            blue: self.internalRGB.blue,
            alpha: self.internalAlpha
        )
    }
    
    public var nsColor: NSColor {
        return NSColor(red: CGFloat(self.rgb.red), green: CGFloat(self.rgb.green), blue: CGFloat(self.rgb.blue), alpha: CGFloat(self.alpha))
    }
    
    public var cgColor: CGColor {
        return CGColor(red: CGFloat(self.rgb.red), green: CGFloat(self.rgb.green), blue: CGFloat(self.rgb.blue), alpha: CGFloat(self.alpha))
    }
    
    
    
    //    MARK: - Enumerations
    
    //    MARK: Public
    
    public enum Range {
        case zero2one
        case zero2twohundredfiftyfive
        case zero2onehundred
        
        var rng: ClosedRange<Double> {
            switch self {
            case .zero2one:
                return 0...1
            case .zero2onehundred:
                return 0...100
            case .zero2twohundredfiftyfive:
                return 0...255
            }
        }
    }
    
    public enum ColorScope {
        case rgb, hsl, hsb, cmyk
        
        enum Values {
            enum RGB {
                case red, green, blue
            }
            
            enum HSL {
                case hue, saturation, lightness
            }
            
            enum HSB {
                case hue, saturation, brightness
            }
            
            enum CMYK {
                case cyan, magenta, yellow, black
            }
            
            enum Other {
                case alpha
            }
        }
    }
    
    
    
    //    MARK: - Initializer
    
    //    MARK: Empty
    
    /// Initializes the color as black and a alpha value of 1.
    init() {
        self.init(red: 0, green: 0, blue: 0)
    }
    
    //    MARK: NSColor
    
    init(_ color: NSColor) {
        guard let cgCS = color.colorSpace.cgColorSpace, let cs = NSColorSpace(cgColorSpace: cgCS), let colorSpace = cs.localizedName else {
            self.init()
            return
        }
        
        if colorSpace.lowercased().contains("rgb") || colorSpace.lowercased().contains("p3") || colorSpace.lowercased().contains("color lcd") {
            
            self.init(red: color.redComponent, green: color.greenComponent, blue: color.blueComponent, alpha: color.alphaComponent)
            
        } else if colorSpace.lowercased().contains("hsb") {
            
            self.init(hue: color.hueComponent, saturation: color.saturationComponent, brightness: color.brightnessComponent, alpha: color.alphaComponent)
            
        } else if colorSpace.lowercased().contains("cmyk") {
            
            self.init(cyan: color.cyanComponent, magenta: color.magentaComponent, yellow: color.yellowComponent, black: color.blackComponent, alpha: color.alphaComponent)
            
        }  else if colorSpace.lowercased().contains("generic gray") {
            
            self.init(hue: 1, saturation: 0, brightness: color.whiteComponent, alpha: color.alphaComponent)
            
        } else {
            self.init()
        }
    }
    
    //    MARK: RGB
    
    /// Initializes the color with a RGB value. The values have to be in a range from zero to one.
    ///
    /// - Parameters:
    ///   - red: A *Double* value representating the red value.
    ///   - green: A *Double* value representating the green value.
    ///   - blue: A *Double* value representating the blue value.
    ///   - alpha: A *Double* value representating the alpha value.
    init(red: Double, green: Double, blue: Double, alpha: Double = 1.0) {
        var r, g, b, a: Double
        
        r = (red > 1 ? 1.0 : red)
        r = (red < 0 ? 0.0 : red)
        
        g = (green > 1 ? 1.0 : green)
        g = (green < 0 ? 0.0 : green)
        
        b = (blue > 1 ? 1.0 : blue)
        b = (blue < 0 ? 0.0 : blue)
        
        a = (alpha > 1 ? 1.0 : alpha)
        a = (alpha < 0 ? 0.0 : alpha)
        
        self.cCalculator = ColorCalculator(red: r, green: g, blue: b)
        
        self.internalRGB = cCalculator.rgb
        self.internalHSL = cCalculator.hsl
        self.internalHSB = cCalculator.hsb
        self.internalCMYK = cCalculator.cmyk
        self.internalAlpha = a
    }
    
    /// Initializes the color with a RGB value. The values have to be in a range from zero to one.
    ///
    /// - Parameters:
    ///   - red: A *CGFloat* value representating the red value.
    ///   - green: A *CGFloat* value representating the green value.
    ///   - blue: A *CGFloat* value representating the blue value.
    ///   - alpha: A *CGFloat* value representating the alpha value.
    init(red: CGFloat, green: CGFloat, blue: CGFloat, alpha: CGFloat = 1.0) {
        self.init(red: Double(red), green: Double(green), blue: Double(blue), alpha: Double(alpha))
    }
    
    /// Initializes the color with a RGB value. The values have to be in a range from 0 to 255.
    ///
    /// - Parameters:
    ///   - red: A *Int* value representating the red value.
    ///   - green: A *Int* value representating the green value.
    ///   - blue: A *Int* value representating the blue value.
    ///   - alpha: The alpha value in percent. Starting from zero and ending with 100.
    init(red: Int, green: Int, blue: Int, alpha: Int = 100) {
        self.init(red: Double(red) / 255, green: Double(green) / 255, blue: Double(blue) / 255, alpha: Double(alpha) / 100)
    }
    
    //    MARK: HSB / HSV
    
    /// Initializes the color with a HSB / HSV value. The value have to be in a range from zero to one.
    ///
    /// - Parameters:
    ///   - hue: A *Double* value representating the hue.
    ///   - saturation: A *Double* value representating the saturation.
    ///   - brightness: A *Double* value representating the brightness.
    ///   - alpha: A *Double* value representating the alpha value.
    init(hue: Double, saturation: Double, brightness: Double, alpha: Double = 1.0) {
        var h, s, b, a: Double
        
        h = (hue > 1 ? 1.0 : hue)
        h = (hue < 0 ? 0.0 : hue)
        
        s = (saturation > 1 ? 1.0 : saturation)
        s = (saturation < 0 ? 0.0 : saturation)
        
        b = (brightness > 1 ? 1.0 : brightness)
        b = (brightness < 0 ? 0.0 : brightness)
        
        a = (alpha > 1 ? 1.0 : alpha)
        a = (alpha < 0 ? 0.0 : alpha)
        
        self.cCalculator = ColorCalculator(hue: h, saturation: s, brightness: b)
        
        self.internalRGB = cCalculator.rgb
        self.internalHSL = cCalculator.hsl
        self.internalHSB = cCalculator.hsb
        self.internalCMYK = cCalculator.cmyk
        self.internalAlpha = a
    }
    
    /// Initializes the color with a HSB / HSV value. The value have to be in a range from zero to one.
    ///
    /// - Parameters:
    ///   - hue: A *CGFloat* value representating the hue.
    ///   - saturation: A *CGFloat* value representating the saturation.
    ///   - brightness: A *CGFloat* value representating the brightness.
    ///   - alpha: A *CGFloat* value representating the alpha value.
    init(hue: CGFloat, saturation: CGFloat, brightness: CGFloat, alpha: CGFloat = 1.0) {
        self.init(hue: Double(hue), saturation: Double(saturation), brightness: Double(brightness), alpha: Double(alpha))
    }
    
    /// Initializes the color with a HSB / HSV value.
    ///
    /// - Parameters:
    ///   - hue: The hue in degrees. Starting from zero and ending with 360.
    ///   - saturation: The saturation in percent. Starting from zero and ending with 100.
    ///   - brightness: The brightness in percent. Starting from zero and ending with 100.
    ///   - alpha: The alpha value in percent. Starting from zero and ending with 100.
    init(hue: Int, saturation: Int, brightness: Int, alpha: Int) {
        self.init(hue: Double(hue) / 360, saturation: Double(saturation) / 100, brightness: Double(brightness) / 100, alpha: Double(alpha) / 100)
    }
    
    //    MARK: HSL
    
    /// Initializes the color with a HSL value. The value have to be in a range from zero to one.
    ///
    /// - Parameters:
    ///   - hue: A *Double* value representating the hue.
    ///   - saturation: A *Double* value representating the saturation.
    ///   - lightness: A *Double* value representating the lightness.
    ///   - alpha: A *Double* value representating the alpha value.
    init(hue: Double, saturation: Double, lightness: Double, alpha: Double = 1.0) {
        var h, s, l, a: Double
        
        h = (hue > 1 ? 1.0 : hue)
        h = (hue < 0 ? 0.0 : hue)
        
        s = (saturation > 1 ? 1.0 : saturation)
        s = (saturation < 0 ? 0.0 : saturation)
        
        l = (lightness > 1 ? 1.0 : lightness)
        l = (lightness < 0 ? 0.0 : lightness)
        
        a = (alpha > 1 ? 1.0 : alpha)
        a = (alpha < 0 ? 0.0 : alpha)
        
        self.cCalculator = ColorCalculator(hue: h, saturation: s, lightness: l)
        
        self.internalRGB = cCalculator.rgb
        self.internalHSL = cCalculator.hsl
        self.internalHSB = cCalculator.hsb
        self.internalCMYK = cCalculator.cmyk
        self.internalAlpha = a
    }
    
    /// Initializes the color with a HSL value. The value have to be in a range from zero to one.
    ///
    /// - Parameters:
    ///   - hue: A *CGFloat* value representating the hue.
    ///   - saturation: A *CGFloat* value representating the saturation.
    ///   - lightness: A *CGFloat* value representating the lightness.
    ///   - alpha: A *CGFloat* value representating the alpha value.
    init(hue: CGFloat, saturation: CGFloat, lightness: CGFloat, alpha: CGFloat = 1.0) {
        self.init(hue: Double(hue), saturation: Double(saturation), lightness: Double(lightness), alpha: Double(alpha))
    }
    
    /// Initializes the color with a HSL value.
    ///
    /// - Parameters:
    ///   - hue: The hue in degrees. Starting from zero and ending with 360.
    ///   - saturation: The saturation in percent. Starting from zero and ending with 100.
    ///   - lightness: The lightness in percent. Starting from zero and ending with 100.
    ///   - alpha: The alpha value in percent. Starting from zero and ending with 100.
    init(hue: Int, saturation: Int, lightness: Int, alpha: Int = 100) {
        self.init(hue: Double(hue) / 360, saturation: Double(saturation) / 100, lightness: Double(lightness) / 100, alpha: Double(alpha) / 100)
    }
    
    //    MARK: CMYK
    
    /// Initializes the color with a CMYK value. The values have to be in a range from zero to one.
    ///
    /// - Parameters:
    ///   - cyan: A *Double* value representating the cyan value.
    ///   - magenta: A *Double* value representating the magenta value.
    ///   - yellow: A *Double* value representating the yellow value.
    ///   - black: A *Double* value representating the black value.
    ///   - alpha: A *Double* value representating the alpha value.
    init(cyan: Double, magenta: Double, yellow: Double, black: Double, alpha: Double = 1.0) {
        var c, m, y, k, a: Double
        
        c = (cyan > 1 ? 1.0 : cyan)
        c = (cyan < 0 ? 0.0 : cyan)
        
        m = (magenta > 1 ? 1.0 : magenta)
        m = (magenta < 0 ? 0.0 : magenta)
        
        y = (yellow > 1 ? 1.0 : yellow)
        y = (yellow < 0 ? 0.0 : yellow)
        
        k = (black > 1 ? 1.0 : black)
        k = (black < 0 ? 0.0 : black)
        
        a = (alpha > 1 ? 1.0 : alpha)
        a = (alpha < 0 ? 0.0 : alpha)
        
        self.cCalculator = ColorCalculator(cyan: c, magenta: m, yellow: y, black: k)
        
        self.internalRGB = cCalculator.rgb
        self.internalHSL = cCalculator.hsl
        self.internalHSB = cCalculator.hsb
        self.internalCMYK = cCalculator.cmyk
        self.internalAlpha = a
    }
    
    /// Initializes the color with a CMYK value. The values have to be in a range from zero to one.
    ///
    /// - Parameters:
    ///   - cyan: A *CGFloat* value representating the cyan value.
    ///   - magenta: A *CGFloat* value representating the magenta value.
    ///   - yellow: A *CGFloat* value representating the yellow value.
    ///   - black: A *CGFloat* value representating the black value.
    ///   - alpha: A *CGFloat* value representating the alpha value.
    init(cyan: CGFloat, magenta: CGFloat, yellow: CGFloat, black: CGFloat, alpha: CGFloat = 1.0) {
        self.init(cyan: Double(cyan), magenta: Double(magenta), yellow: Double(yellow), black: Double(black), alpha: Double(alpha))
    }
    
    /// Initializes the color with a CMYK value.
    ///
    /// - Parameters:
    ///   - cyan: The cyan value in percent. Starting from zero and ending with 100.
    ///   - magenta: The magenta value in percent. Starting from zero and ending with 100.
    ///   - yellow: The yellow value in percent. Starting from zero and ending with 100.
    ///   - black: The black value in percent. Starting from zero and ending with 100.
    ///   - alpha: The alpha value in percent. Starting from zero and ending with 100.
    init(cyan: Int, magenta: Int, yellow: Int, black: Int, alpha: Int = 100) {
        self.init(cyan: Double(cyan) / 100, magenta: Double(magenta) / 100, yellow: Double(yellow) / 100, black: Double(black) / 100, alpha: Double(alpha) / 100)
    }

    
    
    
    //    MARK: - Methods
    
    //    MARK: Private
    
    //    MARK: Public
    
    //    MARK: Get
    
    /// Returns a validated string in a selected format.
    ///
    /// - Parameters:
    ///   - scope: The color scope of the string.
    ///   - alpha: If this parameter is set to true a string with alpha value will be returned. For example: rgba(0, 0, 0, 0.4) instead of rgb(0, 0, 0).
    public func getString(of scope: Color.ColorScope, withAlpha alpha: Bool = false) -> String {
        var str = ""
        
        switch scope {
        case .rgb:
            if !alpha {
                str = "rgb(" +
                    String(Int((self.internalRGB.red * 255).rounded())) + ", " +
                    String(Int((self.internalRGB.green * 255).rounded())) + ", " +
                    String(Int((self.internalRGB.blue * 255).rounded())) + ")"
            } else {
                str = "rgba(" +
                    String(Int((self.internalRGB.red * 255).rounded())) + ", " +
                    String(Int((self.internalRGB.green * 255).rounded())) + ", " +
                    String(Int((self.internalRGB.blue * 255).rounded())) + ", " +
                    self.getAlphaString() + ")"
            }
        case .hsl:
            if !alpha {
                str = "hsl(" +
                    String(Int((self.internalHSL.hue * 360).rounded())) + ", " +
                    String(Int((self.internalHSL.saturation * 100).rounded())) + "%, " +
                    String(Int((self.internalHSL.lightness * 100).rounded())) + "%)"
            } else {
                str = "hsla(" +
                    String(Int((self.internalHSL.hue * 360).rounded())) + ", " +
                    String(Int((self.internalHSL.saturation * 100).rounded())) + "%, " +
                    String(Int((self.internalHSL.lightness * 100).rounded())) + "%, " +
                    self.getAlphaString() + ")"
            }
        case .hsb:
            if !alpha {
                str = "hsb(" +
                    String(Int((self.internalHSB.hue * 360).rounded())) + ", " +
                    String(Int((self.internalHSB.saturation * 100).rounded())) + "%, " +
                    String(Int((self.internalHSB.brightness * 100).rounded())) + "%)"
            } else {
                str = "hsba(" +
                    String(Int((self.internalHSB.hue * 360).rounded())) + ", " +
                    String(Int((self.internalHSB.saturation * 100).rounded())) + "%, " +
                    String(Int((self.internalHSB.brightness * 100).rounded())) + "%, " +
                    self.getAlphaString() + ")"
            }
        case .cmyk:
            str = "cmyk(" +
                String(Int((self.cmyk.cyan * 100).rounded())) + "%, " +
                String(Int((self.cmyk.magenta * 100).rounded())) + "%, " +
                String(Int((self.cmyk.yellow * 100).rounded())) + "%, " +
                String(Int((self.cmyk.black * 100).rounded())) + "%)"
        }
        
        return str
    }
    
    /// Returns a validated string which contains the alpha value of the color.
    ///
    /// - Parameters:
    ///   - decimals: The number of decimals.
    ///   - suffix: A suffix to add to the string. For example: 53**%**
    ///   - range: The range of the alpha value. Available are 0 to 1, 0 to 100, 0 to 255.
    public func getAlphaString(withDecimals decimals: Int = 3, withSuffix suffix: String = "", in range: Color.Range = .zero2one) -> String {
        switch range {
        case .zero2one:
            if decimals == 0 {
                return String(Int(self.alpha.rounded())) + suffix
            } else {
                return String((self.alpha * (10 ** decimals)).rounded() / (10 ** decimals)) + suffix
            }
        case .zero2twohundredfiftyfive:
            if decimals == 0 {
                return String(Int((self.alpha * 255).rounded())) + suffix
            } else {
                return String(((self.alpha * 255) * (10 ** decimals)).rounded() / (10 ** decimals)) + suffix
            }
        case .zero2onehundred:
            if decimals == 0 {
                return String(Int((self.alpha * 100).rounded())) + suffix
            } else {
                return String(((self.alpha * 100) * (10 ** decimals)).rounded() / (10 ** decimals)) + suffix
            }
        }
    }
    
    /// Returns the color as RGB in an specific range.
    public func getRGB(in range: Color.Range) -> (red: Double, green: Double, blue: Double) {
        return (
            red: self.rgb.red * range.rng.upperBound,
            green: self.rgb.green * range.rng.upperBound,
            blue: self.rgb.blue * range.rng.upperBound
        )
    }
    
    /// Returns the color as HSL in an specific range.
    public func getHSL(in range: Color.Range) -> (hue: Double, saturation: Double, lightness: Double) {
        return (
            hue: self.hsl.hue * range.rng.upperBound,
            saturation: self.hsl.saturation * range.rng.upperBound,
            lightness: self.hsl.lightness * range.rng.upperBound
        )
    }
    
    /// Returns the color as HSB in an specific range.
    public func getHSB(in range: Color.Range) -> (hue: Double, saturation: Double, brightness: Double) {
        return (
            hue: self.hsb.hue * range.rng.upperBound,
            saturation: self.hsb.saturation * range.rng.upperBound,
            brightness: self.hsb.brightness * range.rng.upperBound
        )
    }
    
    /// Returns the color as CMYK in an specific range.
    public func getCMYK(in range: Color.Range) -> (cyan: Double, magenta: Double, yellow: Double, black: Double) {
        return (
            cyan: self.cmyk.cyan * range.rng.upperBound,
            magenta: self.cmyk.magenta * range.rng.upperBound,
            yellow: self.cmyk.yellow * range.rng.upperBound,
            black: self.cmyk.black * range.rng.upperBound
        )
    }
    
    /// Returns the alpha value of the color in an specific range.
    public func getAlpha(in range: Color.Range) -> Double {
        return self.alpha * range.rng.upperBound
    }
    
    //    MARK: Set
    
    public mutating func set(color: NSColor) {
        guard let cgCS = color.colorSpace.cgColorSpace, let cs = NSColorSpace(cgColorSpace: cgCS), let colorSpace = cs.localizedName else {
            return
        }
        
        if colorSpace.lowercased().contains("rgb") || colorSpace.lowercased().contains("p3") || colorSpace.lowercased().contains("color lcd") {
            
            self.setRGB([Double(color.redComponent),
                         Double(color.greenComponent),
                         Double(color.blueComponent)],
                        as: .red, .green, .blue,
                        in: .zero2one)
        } else if colorSpace.lowercased().contains("hsb") {

            self.setHSB([Double(color.hueComponent),
                         Double(color.saturationComponent),
                         Double(color.brightnessComponent)],
                        as: .hue, .saturation, .brightness,
                        in: .zero2one)

        } else if colorSpace.lowercased().contains("cmyk") {

            self.setCMYK([Double(color.cyanComponent),
                          Double(color.magentaComponent),
                          Double(color.yellowComponent),
                          Double(color.blackComponent)],
                         as: .cyan, .magenta, .yellow, .black,
                         in: .zero2one)

        }  else if colorSpace.lowercased().contains("generic gray") {

            self.setHSB([1.0,
                         0.0,
                         Double(color.whiteComponent)],
                        as: .hue, .saturation, .brightness,
                        in: .zero2one)
        }
        
        self.setAlpha(Double(color.alphaComponent))
    }
    
    /// Sets a new alpha value for the color.
    ///
    /// - Parameters:
    ///   - raw: The new alpha value.
    ///   - range: The range you want to use.
    public mutating func setAlpha(_ raw: Double, in range: Color.Range = .zero2one) {
        var value = raw
        if value < range.rng.lowerBound {
            value = range.rng.lowerBound
        }
        
        if value > range.rng.upperBound {
            value = range.rng.upperBound
        }
        
        self.internalAlpha = value / range.rng.upperBound
    }
    
    /// Sets new RGB values ​​for the color.
    ///
    /// - Parameters:
    ///   - raw: The new values which replace the old values.
    ///   - value: The values which are to set. The count of parameters should be equal to the count of the *raw value* parameters.
    ///   - range: The range you want to use. Available are 0 to 1, 0 to 100, 0 to 255.
    public mutating func setRGB(_ raw: [Double], as value: ColorScope.Values.RGB..., in range: Color.Range = .zero2one) {
        var rgb = (r: self.rgb.red, g: self.rgb.green, b: self.rgb.blue)
        
        func set(_ raw: Double, loc: inout Double) {
            var value = raw
            if value > range.rng.upperBound {
                value = range.rng.upperBound
            }
            if value < range.rng.lowerBound {
                value = range.rng.lowerBound
            }
            
            loc = value
        }
        
        for x in raw.enumerated() {
            if x.offset < value.count {
                switch value[x.offset] {
                case .red:
                    set(x.element, loc: &rgb.r)
                case .green:
                    set(x.element, loc: &rgb.g)
                case .blue:
                    set(x.element, loc: &rgb.b)
                }
            }
        }
        
        self.cCalculator = ColorCalculator(red: rgb.r / range.rng.upperBound,
                                           green: rgb.g / range.rng.upperBound,
                                           blue: rgb.b / range.rng.upperBound)
        self.internalRGB = (
            red: self.cCalculator.rgb.red,
            green: self.cCalculator.rgb.green,
            blue: self.cCalculator.rgb.blue
        )
        self.internalHSL = (
            hue: self.cCalculator.hsl.hue,
            saturation: self.cCalculator.hsl.saturation,
            lightness: self.cCalculator.hsl.lightness
        )
        self.internalHSB = (
            hue: self.cCalculator.hsb.hue,
            saturation: self.cCalculator.hsb.saturation,
            brightness: self.cCalculator.hsb.brightness
        )
        self.internalCMYK = (
            cyan: self.cCalculator.cmyk.cyan,
            magenta: self.cCalculator.cmyk.magenta,
            yellow: self.cCalculator.cmyk.yellow,
            black: self.cCalculator.cmyk.black
        )
        
    }
    
    /// Sets new HSL values ​​for the color.
    ///
    /// - Parameters:
    ///   - raw: The new values which replace the old values.
    ///   - value: The values which are to set. The count of parameters should be equal to the count of the *raw value* parameters.
    ///   - range: The range you want to use. Available are 0 to 1, 0 to 100, 0 to 255. If you use the range 0 to 100 the hue will be divided with 360 and the rest with 100.
    public mutating func setHSL(_ raw: [Double], as value: ColorScope.Values.HSL..., in range: Color.Range = .zero2one) {
        var hsl = (h: self.hsl.hue, s: self.hsl.saturation, l: self.hsl.lightness)
        
        func set(_ raw: Double, loc: inout Double) {
            var value = raw
            if value > range.rng.upperBound {
                value = range.rng.upperBound
            }
            if value < range.rng.lowerBound {
                value = range.rng.lowerBound
            }
            
            loc = value
        }
        
        for x in raw.enumerated() {
            if x.offset < value.count {
                switch value[x.offset] {
                case .hue:
                    set(x.element, loc: &hsl.h)
                case .saturation:
                    set(x.element, loc: &hsl.s)
                case .lightness:
                    set(x.element, loc: &hsl.l)
                }
            }
        }
        
        self.cCalculator = ColorCalculator(hue: hsl.h / range.rng.upperBound,
                                           saturation: hsl.s / range.rng.upperBound,
                                           lightness: hsl.l / range.rng.upperBound)
        self.internalRGB = (
            red: self.cCalculator.rgb.red,
            green: self.cCalculator.rgb.green,
            blue: self.cCalculator.rgb.blue
        )
        self.internalHSL = (
            hue: self.cCalculator.hsl.hue,
            saturation: self.cCalculator.hsl.saturation,
            lightness: self.cCalculator.hsl.lightness
        )
        self.internalHSB = (
            hue: self.cCalculator.hsb.hue,
            saturation: self.cCalculator.hsb.saturation,
            brightness: self.cCalculator.hsb.brightness
        )
        self.internalCMYK = (
            cyan: self.cCalculator.cmyk.cyan,
            magenta: self.cCalculator.cmyk.magenta,
            yellow: self.cCalculator.cmyk.yellow,
            black: self.cCalculator.cmyk.black
        )
    }
    
    /// Sets new HSB values ​​for the color.
    ///
    /// - Parameters:
    ///   - raw: The new values which replace the old values.
    ///   - value: The values which are to set. The count of parameters should be equal to the count of the *raw value* parameters.
    ///   - range: The range you want to use. Available are 0 to 1, 0 to 100, 0 to 255.
    public mutating func setHSB(_ raw: [Double], as value: ColorScope.Values.HSB..., in range: Color.Range = .zero2one) {
        var hsb = (h: self.hsb.hue, s: self.hsb.saturation, b: self.hsb.brightness)
        
        func set(_ raw: Double, loc: inout Double) {
            var value = raw
            if value > range.rng.upperBound {
                value = range.rng.upperBound
            }
            if value < range.rng.lowerBound {
                value = range.rng.lowerBound
            }
            
            loc = value
        }
        
        for x in raw.enumerated() {
            if x.offset < value.count {
                switch value[x.offset] {
                case .hue:
                    set(x.element, loc: &hsb.h)
                case .saturation:
                    set(x.element, loc: &hsb.s)
                case .brightness:
                    set(x.element, loc: &hsb.b)
                }
            }
        }
        
        self.cCalculator = ColorCalculator(hue: hsb.h / range.rng.upperBound,
                                           saturation: hsb.s / range.rng.upperBound,
                                           brightness: hsb.b / range.rng.upperBound)
        self.internalRGB = (
            red: self.cCalculator.rgb.red,
            green: self.cCalculator.rgb.green,
            blue: self.cCalculator.rgb.blue
        )
        self.internalHSL = (
            hue: self.cCalculator.hsl.hue,
            saturation: self.cCalculator.hsl.saturation,
            lightness: self.cCalculator.hsl.lightness
        )
        self.internalHSB = (
            hue: self.cCalculator.hsb.hue,
            saturation: self.cCalculator.hsb.saturation,
            brightness: self.cCalculator.hsb.brightness
        )
        self.internalCMYK = (
            cyan: self.cCalculator.cmyk.cyan,
            magenta: self.cCalculator.cmyk.magenta,
            yellow: self.cCalculator.cmyk.yellow,
            black: self.cCalculator.cmyk.black
        )
    }
    
    /// Sets new CMYK values ​​for the color.
    ///
    /// - Parameters:
    ///   - raw: The new values which replace the old values.
    ///   - value: The values which are to set. The count of parameters should be equal to the count of the *raw value* parameters.
    ///   - range: The range you want to use. Available are 0 to 1, 0 to 100, 0 to 255.
    public mutating func setCMYK(_ raw: [Double], as value: ColorScope.Values.CMYK..., in range: Color.Range = .zero2one) {
        var cmyk = (c: self.cmyk.cyan, m: self.cmyk.magenta, y: self.cmyk.yellow, k: self.cmyk.black)
        
        func set(_ raw: Double, loc: inout Double) {
            var value = raw
            if value > range.rng.upperBound {
                value = range.rng.upperBound
            }
            if value < range.rng.lowerBound {
                value = range.rng.lowerBound
            }
            
            loc = value
        }
        
        for x in raw.enumerated() {
            if x.offset < value.count {
                switch value[x.offset] {
                case .cyan:
                    set(x.element, loc: &cmyk.c)
                case .magenta:
                    set(x.element, loc: &cmyk.m)
                case .yellow:
                    set(x.element, loc: &cmyk.y)
                case .black:
                    set(x.element, loc: &cmyk.k)
                }
            }
        }
        
        self.cCalculator = ColorCalculator(cyan: cmyk.c / range.rng.upperBound,
                                           magenta: cmyk.m / range.rng.upperBound,
                                           yellow: cmyk.y / range.rng.upperBound,
                                           black: cmyk.k / range.rng.upperBound)
        self.internalRGB = (
            red: self.cCalculator.rgb.red,
            green: self.cCalculator.rgb.green,
            blue: self.cCalculator.rgb.blue
        )
        self.internalHSL = (
            hue: self.cCalculator.hsl.hue,
            saturation: self.cCalculator.hsl.saturation,
            lightness: self.cCalculator.hsl.lightness
        )
        self.internalHSB = (
            hue: self.cCalculator.hsb.hue,
            saturation: self.cCalculator.hsb.saturation,
            brightness: self.cCalculator.hsb.brightness
        )
        self.internalCMYK = (
            cyan: self.cCalculator.cmyk.cyan,
            magenta: self.cCalculator.cmyk.magenta,
            yellow: self.cCalculator.cmyk.yellow,
            black: self.cCalculator.cmyk.black
        )
    }
}
