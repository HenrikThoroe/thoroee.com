//
//  AppDelegate.swift
//  Quick Colour
//
//  Created by Henrik Thoroe on 29.01.18.
//  Copyright © 2018 Henrik Thoroe. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    //    MARK: - Properties
    
    var mainVC: ViewController!
    
    let statusBarItem = NSStatusBar.system.statusItem(withLength: -1)
    
    
    
    //    MARK: - Initializer
    
    override init() {
        super.init()
        
        let userDefaults = UserDefaults.standard
        if let url = Bundle.main.url(forResource: "appDefaults", withExtension: "plist"),
            let appDefaults = NSDictionary(contentsOf: url) {
            userDefaults.register(defaults: appDefaults as! [String : AnyObject])
        }
    }
    
    
    
    //    MARK: - Methods
    
    //    MARK: App Delegate Internal
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        let icon = #imageLiteral(resourceName: "MenuBarImage")
        
        if let button = statusBarItem.button {
            button.image = icon
            button.target = self
            button.action = #selector(self.showWindowFromStatusBarItem(_:))
            button.sendAction(on: .leftMouseDown)
        }
    }
    
    //    MARK: Private
    
    @objc func showWindowFromStatusBarItem(_ sender: NSStatusBarButton) {
        guard let event = NSApp.currentEvent else {
            return
        }
        
        if event.modifierFlags.rawValue == 524320 {
            mainVC?.view.window?.makeKeyAndOrderFront(self)
        } else {
            let menu: NSMenu = NSMenu()
            menu.delegate = self
            
            var menuItem = NSMenuItem()
            menuItem.title = "Show Window"
            menuItem.action = #selector(AppDelegate.showWindow(_:))
            menu.addItem(menuItem)
            
            menuItem = NSMenuItem.separator()
            menu.addItem(menuItem)
            
            menuItem = NSMenuItem()
            menuItem.title = "Quit"
            menuItem.action = #selector(AppDelegate.terminate(_:))
            menu.addItem(menuItem)
            
            statusBarItem.popUpMenu(menu)
        }
    }
    
    @objc private func showWindow(_ sender: NSMenuItem) {
        mainVC?.view.window?.makeKeyAndOrderFront(self)
    }
    
    @objc private func terminate(_ sender: NSMenuItem) {
        NSApplication.shared.terminate(self)
    }

}

extension AppDelegate: NSMenuDelegate {
    func menuDidClose(_ menu: NSMenu) {
        statusBarItem.menu = nil
    }
}

