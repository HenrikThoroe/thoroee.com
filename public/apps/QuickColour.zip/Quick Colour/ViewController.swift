//
//  ViewController.swift
//  Quick Colour
//
//  Created by Henrik Thoroe on 29.01.18.
//  Copyright © 2018 Henrik Thoroe. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {
    //    MARK: - Outlets
    
    //    MARK: Global
    
    @IBOutlet weak var ColorWell: NSColorWell!
    @IBOutlet weak var TextField: NSTextField!
    @IBOutlet weak var CheckBox: NSImageView!
    
    //    MARK: Web
    
    @IBOutlet weak var WebHex: NSButton!
    @IBOutlet weak var WebRGB: NSButton!
    @IBOutlet weak var WebHSL: NSButton!
    @IBOutlet weak var WebRGBA: NSButton!
    @IBOutlet weak var WebHSLA: NSButton!
    @IBOutlet weak var WebOpacity: NSButton!
    
    //    MARK: App
    
    @IBOutlet weak var AppNSColor: NSButton!
    @IBOutlet weak var AppCGColor: NSButton!
    
    //    MARK: Graphic
    
    @IBOutlet weak var GraphicRGB: NSButton!
    @IBOutlet weak var GraphicHSB: NSButton!
    @IBOutlet weak var GraphicHSL: NSButton!
    @IBOutlet weak var GraphicCMYK: NSButton!
    @IBOutlet weak var GraphicOpacity: NSButton!
    
    
    
    //    MARK: - Properties
    
    //    MARK: Private
    
    private let app = NSApplication.shared.delegate as! AppDelegate
    
    private let colorPicker = NSColorPanel.shared
    
    private var color: Color = Color() {
        didSet {
            enableButtons()
            
            // Web
            WebRGB.title = color.getString(of: .rgb)
            WebHSL.title = color.getString(of: .hsl)
            WebRGBA.title = color.getString(of: .rgb, withAlpha: true)
            WebHSLA.title = color.getString(of: .hsl, withAlpha: true)
            WebOpacity.title = color.getAlphaString(withDecimals: 3, withSuffix: "", in: .zero2one)
            WebHex.title = color.hex
            
            // Graphic
            GraphicHSB.title = color.getString(of: .hsb)
            GraphicHSL.title = color.getString(of: .hsl)
            GraphicRGB.title = color.getString(of: .rgb)
            GraphicCMYK.title = color.getString(of: .cmyk)
            GraphicOpacity.title = color.getAlphaString(withDecimals: 0, withSuffix: "%", in: .zero2onehundred)
            
            // App
            AppCGColor.title = "CGColor(red: " +
                String((color.rgb.red * 1000).rounded() / 1000) + ", green: " +
                String((color.rgb.green * 1000).rounded() / 1000) + ", blue: " +
                String((color.rgb.blue * 1000).rounded() / 1000) + ", alpha: " +
                String((color.alpha * 1000).rounded() / 1000) + ")"
            
            AppNSColor.title = "NSColor(red: " +
                String((color.rgb.red * 1000).rounded() / 1000) + ", green: " +
                String((color.rgb.green * 1000).rounded() / 1000) + ", blue: " +
                String((color.rgb.blue * 1000).rounded() / 1000) + ", alpha: " +
                String((color.alpha * 1000).rounded() / 1000) + ")"
        }
    }
    
    
    
    //    MARK: - Methods
    
    //    MARK: Override

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Color Picker / Weel
        colorPicker.showsAlpha = true
        
        // Global Style
        CheckBox.isHidden = true
        
        app.mainVC = self
    }
    
    override func viewDidAppear() {
        super.viewDidAppear()
    }
    
    //    MARK: IBAction
    
    @IBAction func updateColor(_ sender: NSColorWell) {
        sender.alphaValue = sender.color.alphaComponent
        self.color.set(color: sender.color)
        
        sender.color = self.color.nsColor.withAlphaComponent(1.0)
    }
    
    @IBAction func copyValue(_ sender: NSButton) {
        addToClipboard(string: sender.title)
        CheckBox.isHidden = false
        NSSound(named: NSSound.Name(rawValue: "Ping"))?.play()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.CheckBox.isHidden = true
        }
    }
    
    @IBAction func getColorValue(_ sender: NSTextField) {
        let raw = sender.stringValue
        
        DispatchQueue.main.async {
            self.view.window?.makeFirstResponder(nil)
        }
        
        func extractRGB(_ numbers: [String]) {
            if numbers.count != 3 {
                return
            }
            
            guard let first = Double(numbers[0]), let second = Double(numbers[1]), let third = Double(numbers[2]) else {
                return
            }
            
            self.color.setRGB([first, second, third], as: .red, .green, .blue, in: .zero2twohundredfiftyfive)
            ColorWell.color = self.color.nsColor
        }
        
        func extractRGBA(_ numbers: [String]) {
            if numbers.count != 4 {
                return
            }
            
            guard let first = Double(numbers[0]), let second = Double(numbers[1]), let third = Double(numbers[2]), let fourth = Double(numbers[3]) else {
                return
            }
            
            self.color.setRGB([first, second, third], as: .red, .green, .blue, in: .zero2twohundredfiftyfive)
            self.color.setAlpha(fourth, in: .zero2one)
            ColorWell.color = self.color.nsColor
            ColorWell.alphaValue = CGFloat(self.color.alpha)
            ColorWell.color = self.color.nsColor.withAlphaComponent(1.0)
        }
        
        func extractHSL(_ numbers: [String]) {
            if numbers.count != 3 {
                return
            }
            
            guard let first = Double(numbers[0]), let second = Double(numbers[1]), let third = Double(numbers[2]) else {
                return
            }
            
            self.color.setHSL([first / 3.6, second, third], as: .hue, .saturation, .lightness, in: .zero2onehundred)
            ColorWell.color = self.color.nsColor
        }
        
        func extractHSLA(_ numbers: [String]) {
            if numbers.count != 4 {
                return
            }
            
            guard let first = Double(numbers[0]), let second = Double(numbers[1]), let third = Double(numbers[2]), let fourth = Double(numbers[3]) else {
                return
            }
            
            self.color.setHSL([first / 3.6, second, third], as: .hue, .saturation, .lightness, in: .zero2onehundred)
            self.color.setAlpha(fourth, in: .zero2one)
            ColorWell.color = self.color.nsColor
            ColorWell.alphaValue = CGFloat(self.color.alpha)
            ColorWell.color = self.color.nsColor.withAlphaComponent(1.0)
        }
        
        func extractHSB(_ numbers: [String]) {
            if numbers.count != 3 {
                return
            }
            
            guard let first = Double(numbers[0]), let second = Double(numbers[1]), let third = Double(numbers[2]) else {
                return
            }
            
            self.color.setHSB([first / 3.6, second, third], as: .hue, .saturation, .brightness, in: .zero2onehundred)
            ColorWell.color = self.color.nsColor
        }
        
        func extractHSBA(_ numbers: [String]) {
            if numbers.count != 4 {
                return
            }
            
            guard let first = Double(numbers[0]), let second = Double(numbers[1]), let third = Double(numbers[2]), let fourth = Double(numbers[3]) else {
                return
            }
            
            self.color.setHSB([first / 3.6, second, third], as: .hue, .saturation, .brightness, in: .zero2onehundred)
            self.color.setAlpha(fourth, in: .zero2one)
            ColorWell.color = self.color.nsColor
            ColorWell.alphaValue = CGFloat(self.color.alpha)
            ColorWell.color = self.color.nsColor.withAlphaComponent(1.0)
        }
        
        func extractCMYK(_ numbers: [String]) {
            if numbers.count != 4 {
                return
            }
            
            guard let first = Double(numbers[0]), let second = Double(numbers[1]), let third = Double(numbers[2]), let fourth = Double(numbers[3]) else {
                return
            }
            
            self.color.setCMYK([first, second, third, fourth], as: .cyan, .magenta, .yellow, .black, in: .zero2onehundred)
            ColorWell.color = self.color.nsColor
        }
        
        // Hexadecimal
        if raw.hasPrefix("#") {
            var str = raw
            str.clean(from: "#")
            
            if str.len == 3 {
                guard let red = Int(str[0, 1] + str[0, 1], radix: 16),
                    let green = Int(str[1, 2] + str[1, 2], radix: 16),
                    let blue = Int(str[2, 3] + str[2, 3], radix: 16) else {
                    return
                }
                
                self.color.setRGB([Double(red), Double(green), Double(blue)], as: .red, .green, .blue, in: .zero2twohundredfiftyfive)
                ColorWell.color = self.color.nsColor
            } else if str.len == 6 {
                guard let red = Int(str[0, 2], radix: 16), let green = Int(str[2, 4], radix: 16), let blue = Int(str[4, 6], radix: 16) else {
                    return
                }
                
                self.color.setRGB([Double(red), Double(green), Double(blue)], as: .red, .green, .blue, in: .zero2twohundredfiftyfive)
                ColorWell.color = self.color.nsColor
            }
            
            return
        }
        
        guard var type = raw.slice(from: raw[0], to: "("), var body = raw.slice(from: "(", to: ")") else {
            return
        }
        
        if !raw.contains(")") || raw.number(of: "(") > 1 || raw.number(of: ")") > 1 {
            return
        }
        
        body.clean(from: " ")
        body.clean(from: "%")
        let numbers = body.split(separator: ",").map() { String($0) }
        type = (raw[0] + type).lowercased()
        
        switch type {
        case "rgb":
            extractRGB(numbers)
        case "rgba":
            extractRGBA(numbers)
        case "hsl":
            extractHSL(numbers)
        case "hsla":
            extractHSLA(numbers)
        case "hsb":
            extractHSB(numbers)
        case "hsba":
            extractHSBA(numbers)
        case "cmyk":
            extractCMYK(numbers)
        default:
            return
        }
    }
    
    //    MARK: Private
    
    private func enableButtons() {
        // Web
        WebHex.isEnabled = true
        WebHSL.isEnabled = true
        WebHSLA.isEnabled = true
        WebRGBA.isEnabled = true
        WebOpacity.isEnabled = true
        WebRGB.isEnabled = true
        
        // App
        AppCGColor.isEnabled = true
        AppNSColor.isEnabled = true
        
        // Graphic
        GraphicHSB.isEnabled = true
        GraphicHSL.isEnabled = true
        GraphicRGB.isEnabled = true
        GraphicCMYK.isEnabled = true
        GraphicOpacity.isEnabled = true
    }
    
    private func disableButtons() {
        // Web
        WebHex.isEnabled = false
        WebHSL.isEnabled = false
        WebHSLA.isEnabled = false
        WebRGBA.isEnabled = false
        WebOpacity.isEnabled = false
        WebRGB.isEnabled = false
        
        // App
        AppCGColor.isEnabled = false
        AppNSColor.isEnabled = false
        
        // Graphic
        GraphicHSB.isEnabled = false
        GraphicHSL.isEnabled = false
        GraphicRGB.isEnabled = false
        GraphicCMYK.isEnabled = false
        GraphicOpacity.isEnabled = false
    }

}

