//
//  Globals.swift
//  Quick Colour
//
//  Created by Henrik Thoroe on 29.01.18.
//  Copyright © 2018 Henrik Thoroe. All rights reserved.
//

import Foundation


