//
//  Extensions.swift
//  Quick Colour
//
//  Created by Henrik Thoroe on 29.01.18.
//  Copyright © 2018 Henrik Thoroe. All rights reserved.
//

import Foundation

extension String {
    
    var len: Int {
        return self.count
    }
    
    subscript(start: Int, end: Int) -> String {
        var n1 = start, n2 = end
        if n1 < 0 { n1 = 0 }
        if n1 > self.len { n1 = self.len }
        if n2 < 0 { n2 = 0 }
        if n2 > self.len { n2 = self.len }
        
        if n2 < n1 { return "" }
        else {
            let pos1 = self.index(self.startIndex, offsetBy: IndexDistance(Double(n1)))
            let pos2 = self.index(self.startIndex, offsetBy: IndexDistance(Double(n2)))
            return String(self[pos1 ..< pos2])
        }
    }
    
    subscript(n: Int) -> String {
        return self[n, n+1]
    }
    
    subscript(rng: Range<Int>) -> String {
        return self[rng.lowerBound, rng.upperBound]
    }
    
    subscript(rng: ClosedRange<Int>) -> String {
        return self[rng.lowerBound, rng.upperBound]
    }
    
    func slice(from: String, to: String) -> String? {
        
        return (range(of: from)?.upperBound).flatMap {
            substringFrom in (range(of: to, range: substringFrom..<endIndex)?.lowerBound).map {
                substringTo in String(self[substringFrom..<substringTo])
            }
        }
    }
    
    func number(of character: Character) -> Int {
        var counter = 0
        for char in self {
            if char == character {
                counter += 1
            }
        }
        
        return counter
    }
    
    mutating func clean(from character: Character) {
        var new = ""
        
        for char in self {
            if char != character {
                new += String(char)
            }
        }
        
        self = new
    }
    
    mutating func delete(at position: Int) {
        if position < 0 { return }
        if position >= self.len { return }
        
        if position == 0 {
            self = self[1 ..< self.len]
        } else if position == self.len {
            self = self[0 ..< self.len - 1]
        } else  {
            self = self[0 ..< position] + self[position + 1 ..< self.len]
        }
    }
    
    func delete(at position: Int) -> String {
        let str: String
        
        if position < 0 { return self }
        if position >= self.len { return self }
        
        if position == 0 {
            str = self[1 ..< self.len]
        } else if position == self.len {
            str = self[0 ..< self.len - 1]
        } else  {
            str = self[0 ..< position] + self[position + 1 ..< self.len]
        }
        
        return str
    }
    
    func trim(in characterSet: CharacterSet) -> String {
        return self.trimmingCharacters(in: characterSet)
    }
    
    var digits: String {
        return components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
    }
    
    var specialChars: String {
        let comps = (components(separatedBy: CharacterSet.nonBaseCharacters.inverted).joined(),
                     components(separatedBy: CharacterSet.punctuationCharacters.inverted).joined(),
                     components(separatedBy: CharacterSet.symbols.inverted).joined(),
                     components(separatedBy: CharacterSet.whitespacesAndNewlines.inverted).joined())
        
        return comps.0 + comps.1 + comps.2 + comps.3
    }
    
    var uppercassedLetters: String {
        return components(separatedBy: CharacterSet.uppercaseLetters.inverted).joined()
    }
    
    var lowercassedLetters: String {
        return components(separatedBy: CharacterSet.lowercaseLetters.inverted).joined()
    }
    
    var variousChars: String {
        let chars = Set(self)
        let arr = Array(chars).map() { String($0) }
        return arr.sorted(by: <).joined()
    }
    
    var isNumber: Bool {
        if Int(self) != nil || UInt(self) != nil || Double(self) != nil {
            return true
        } else {
            return false
        }
    }
    
}
