//
//  Functions.swift
//  Quick Colour
//
//  Created by Henrik Thoroe on 29.01.18.
//  Copyright © 2018 Henrik Thoroe. All rights reserved.
//

import Cocoa

func random(_ start: Int, _ end: Int) -> Int {
    if start == end { return start }
    if end < start { return start }
     
    if end < 0 {
        let _start = start - (2 * start)
        let _end = end - (2 * end)
        let rand = Int(arc4random_uniform(UInt32(_start))) + _end
        return rand - (2 * rand)
    } else {
        return Int(arc4random_uniform(UInt32(end + 1))) + start
    }
}

func random(_ range: Range<Int>) -> Int {
    return random(range.lowerBound, range.upperBound)
}

func random(_ range: ClosedRange<Int>) -> Int {
    return random(range.lowerBound, range.upperBound)
}

func addToClipboard(string: String) {
    let pasteboard = NSPasteboard.general
    pasteboard.declareTypes([.string], owner: nil)
    pasteboard.setString(string, forType: .string)
}
