//
//  ColorCalculator.swift
//  Quick Colour
//
//  Created by Henrik Thoroe on 30.01.18.
//  Copyright © 2018 Henrik Thoroe. All rights reserved.
//

import Cocoa

class ColorCalculator {
    //    MARK: - Properties
    
    //    MARK: Private
    
    private var red: Double
    
    private var green: Double
    
    private var blue: Double
    
    //    MARK: Public
    
    public var hsl: (hue: Double, saturation: Double, lightness: Double) {
        let calc = self.calculateHSL()
        
        return (hue: calc.0, saturation: calc.1, lightness: calc.2)
    }
    
    public var hsb: (hue: Double, saturation: Double, brightness: Double) {
        let calc = self.calculateHSB()
        
        return (hue: calc.0, saturation: calc.1, brightness: calc.2)
    }
    
    public var rgb: (red: Double, green: Double, blue: Double) {
        return (red: self.red, green: self.green, blue: self.blue)
    }
    
    public var cmyk: (cyan: Double, magenta: Double, yellow: Double, black: Double) {
        let calc = self.calculateCMYK()
        
        return (cyan: calc.0, magenta: calc.1, yellow: calc.2, black: calc.3)
    }
    
    
    
    //    MARK: - Initializer
    
    init(red: Double, green: Double, blue: Double) {
        var r, g, b: Double
        
        r = (red > 1 ? 1.0 : red)
        r = (red < 0 ? 0.0 : red)
        
        g = (green > 1 ? 1.0 : green)
        g = (green < 0 ? 0.0 : green)
        
        b = (blue > 1 ? 1.0 : blue)
        b = (blue < 0 ? 0.0 : blue)
        
        self.red = r
        self.green = g
        self.blue = b
    }
    
    init(hue: Double, saturation: Double, lightness: Double) {
        var h, s, l: Double
        
        h = (hue > 1 ? 1.0 : hue)
        h = (hue < 0 ? 0.0 : hue)
        
        s = (saturation > 1 ? 1.0 : saturation)
        s = (saturation < 0 ? 0.0 : saturation)
        
        l = (lightness > 1 ? 1.0 : lightness)
        l = (lightness < 0 ? 0.0 : lightness)
        
        self.red = 0.0
        self.green = 0.0
        self.blue = 0.0
        
        let calc = self.calculateRGB(hue: h, saturation: s, lightness: l)
        
        self.red = calc.0
        self.green = calc.1
        self.blue = calc.2
    }
    
    init(hue: Double, saturation: Double, brightness: Double) {
        var h, s, b: Double
        
        h = (hue > 1 ? 1.0 : hue)
        h = (hue < 0 ? 0.0 : hue)
        
        s = (saturation > 1 ? 1.0 : saturation)
        s = (saturation < 0 ? 0.0 : saturation)
        
        b = (brightness > 1 ? 1.0 : brightness)
        b = (brightness < 0 ? 0.0 : brightness)
        
        self.red = 0.0
        self.green = 0.0
        self.blue = 0.0
        
        let calc = self.calculateRGB(hue: h, saturation: s, brightness: b)
        
        self.red = calc.0
        self.green = calc.1
        self.blue = calc.2
    }
    
    init(cyan: Double, magenta: Double, yellow: Double, black: Double) {
        var c, m, y, k: Double
        
        c = (cyan > 1 ? 1.0 : cyan)
        c = (cyan < 0 ? 0.0 : cyan)
        
        m = (magenta > 1 ? 1.0 : magenta)
        m = (magenta < 0 ? 0.0 : magenta)
        
        y = (yellow > 1 ? 1.0 : yellow)
        y = (yellow < 0 ? 0.0 : yellow)
        
        k = (black > 1 ? 1.0 : black)
        k = (black < 0 ? 0.0 : black)
        
        self.red = 0.0
        self.green = 0.0
        self.blue = 0.0
        
        let calc = self.calculateRGB(cyan: c, magenta: m, yellow: y, black: k)
        
        self.red = calc.0
        self.green = calc.1
        self.blue = calc.2
    }
    
    
    
    //    MARK: - Methods
    
    //    MARK: Private
    
    private func calculateRGB(cyan: Double, magenta: Double, yellow: Double, black: Double) -> (Double, Double, Double) {
        
        guard let color = NSColor(deviceCyan: CGFloat(cyan), magenta: CGFloat(magenta), yellow: CGFloat(yellow), black: CGFloat(black), alpha: 1).usingColorSpace(.genericRGB) else {
            return(0, 0, 0)
        }
        
        return (Double(color.redComponent),
                Double(color.greenComponent),
                Double(color.blueComponent)
        )
    }
    
    private func calculateRGB(hue: Double, saturation: Double, lightness: Double) -> (Double, Double, Double) {
        var rgb = (red: 0.0, green: 0.0, blue: 0.0)
        var storage = (0.0, 0.0)
        
        func hue2rgb(hue: Double, _ storage: (Double, Double)) -> Double {
            var internalStorage = (hue: hue, var1: storage.0, var2: storage.1)
            
            if hue < 0 {
                internalStorage.hue += 1
            }
            
            if hue > 1 {
                internalStorage.hue -= 1
            }
            
            if (6 * hue) < 1 {
                return (internalStorage.var1 + (internalStorage.var2 - internalStorage.var1) * 6 * hue)
            }
            
            if (2 * hue) < 1 {
                return internalStorage.var2;
            }
            
            if (3 * hue) < 2 {
                return internalStorage.var1 + (internalStorage.var2 - internalStorage.var1) * ((2 / 3 - hue) * 6)
            }
            
            return internalStorage.var1
        }
        
        if saturation == 0 {
            rgb.red = lightness
            rgb.green = lightness
            rgb.blue = lightness
        } else {
            if lightness < 0.5 {
                storage.1 = lightness * (1 + saturation)
            } else {
                storage.1 = (lightness + saturation) - (saturation * lightness)
            }
            
            storage.0 = 2 * lightness - storage.1
            rgb.red = hue2rgb(hue: hue + (1 / 3), (storage.0, storage.1))
            rgb.green = hue2rgb(hue: hue, (storage.0, storage.1))
            rgb.blue = hue2rgb(hue: hue - (1 / 3), (storage.0, storage.1))
        }
        
        return (rgb.red, rgb.green, rgb.blue)
    }
    
    private func calculateRGB(hue: Double, saturation: Double, brightness: Double) -> (Double, Double, Double) {
        var rgb = (red: 0.0, green: 0.0, blue: 0.0)
        let i = (hue * 6).rounded(.down)
        let f = hue * 6 - i
        let p = brightness * (1 - saturation)
        let q = brightness * (1 - f * saturation)
        let t = brightness * (1 - (1 - f) * saturation)
        
        switch i.truncatingRemainder(dividingBy: 6) {
        case 0:
            rgb.red = brightness
            rgb.green = t
            rgb.blue = p
        case 1:
            rgb.red = q
            rgb.green = brightness
            rgb.blue = p
        case 2:
            rgb.red = p
            rgb.green = brightness
            rgb.blue = t
        case 3:
            rgb.red = p
            rgb.green = q
            rgb.blue = brightness
        case 4:
            rgb.red = t
            rgb.green = p
            rgb.blue = brightness
        case 5:
            rgb.red = brightness
            rgb.green = p
            rgb.blue = q
        default:
            break
        }
        
        return (rgb.red, rgb.green, rgb.blue)
    }
    
    private func calculateCMYK() -> (Double, Double, Double, Double) {
        let c = NSColor(red: CGFloat(self.red), green: CGFloat(self.green), blue: CGFloat(self.blue), alpha: 1.0)
        
        guard let color = c.usingColorSpace(.genericCMYK) else {
            return (0, 0, 0, 0)
        }
        
        return (Double(color.cyanComponent),
                Double(color.magentaComponent),
                Double(color.yellowComponent),
                Double(color.blackComponent)
        )
    }
    
    private func calculateHSB() -> (Double, Double, Double) {
        let minValue = min(self.red, self.green, self.blue)
        let maxValue = max(self.red, self.green, self.blue)
        let delta = maxValue - minValue
        let hsl = self.calculateHSL()
        var hsb = (hue: hsl.0, saturation: 0.0, brightness: 0.0)
        
        hsb.brightness = maxValue
        if maxValue == 0 {
            hsb.saturation = 0
        } else {
            hsb.saturation = delta / maxValue
        }
        
        return (hsb.hue, hsb.saturation, hsb.brightness)
    }
    
    private func calculateHSL() -> (Double, Double, Double) {
        let minValue = min(self.red, self.green, self.blue)
        let maxValue = max(self.red, self.green, self.blue)
        let delta = maxValue - minValue

        var hsl = (hue: 0.0, saturation: 0.0, lightness: 0.0)

        hsl.lightness = (maxValue + minValue) / 2

        if delta == 0 {
            hsl.hue = 0
            hsl.saturation = 0
        } else {
            if hsl.lightness < 0.5 {
                hsl.saturation = delta / (maxValue + minValue)
            } else {
                hsl.saturation = delta / (2 - maxValue - minValue)
            }

            let deltaRed =  (((maxValue - self.red) / 6) + (delta / 2)) / delta
            let deltaGreen = (((maxValue - self.green) / 6) + (delta / 2)) / delta
            let deltaBlue = (((maxValue - self.blue) / 6) + (delta / 2)) / delta

            if self.red == maxValue {
                hsl.hue = deltaBlue - deltaGreen
            } else if self.green == maxValue {
                hsl.hue = (1 / 3) + deltaRed - deltaBlue
            } else if self.blue == maxValue {
                hsl.hue = (2 / 3) + deltaGreen - deltaRed
            }

            if hsl.hue < 0 {
                hsl.hue += 1
            }

            if hsl.hue > 1 {
                hsl.hue -= 1
            }
        }

        return (hsl.hue, hsl.saturation, hsl.lightness)
    }
    
    //    MARK: Public
}
